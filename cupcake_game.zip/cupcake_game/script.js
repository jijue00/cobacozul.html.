const game = document.getElementById("game");
const player = document.getElementById("player");
const popup = document.getElementById("popup");
const scoreEl = document.getElementById("score");

let playerX = 160;
let score = 0;
let gameInterval, spawnInterval;

// gerak kiri kanan
document.addEventListener("keydown", e => {
  if (e.key === "ArrowLeft") {
    playerX -= 20;
    if (playerX < 0) playerX = 0;
  } else if (e.key === "ArrowRight") {
    playerX += 20;
    if (playerX > 320) playerX = 320;
  }
  player.style.left = playerX + "px";
});

// spawn item jatuh
function spawnItem() {
  const item = document.createElement("img");
  item.classList.add("falling");
  const type = Math.random() < 0.8 ? "cupcake" : "bomb";
  item.src = type === "cupcake" ? "assets/cupcake.png" : "assets/bomb.png";
  item.dataset.type = type;
  item.style.left = Math.floor(Math.random() * 340) + "px";
  game.appendChild(item);

  let fall = setInterval(() => {
    let top = parseInt(item.style.top || "0");
    item.style.top = top + 5 + "px";

    // tabrakan
    if (top > 420 && top < 500) {
      let playerLeft = playerX;
      let playerRight = playerX + 80;
      let itemLeft = parseInt(item.style.left);
      let itemRight = itemLeft + 60;

      if (itemRight > playerLeft && itemLeft < playerRight) {
        if (item.dataset.type === "cupcake") {
          score++;
          scoreEl.innerText = "Score: " + score;
        } else {
          endGame();
        }
        clearInterval(fall);
        item.remove();
      }
    }

    // lewat bawah
    if (top > 500) {
      clearInterval(fall);
      item.remove();
    }
  }, 30);
}

// mulai game
function startGame() {
  score = 0;
  scoreEl.innerText = "Score: 0";
  popup.classList.add("hidden");
  gameInterval = setInterval(() => {}, 30);
  spawnInterval = setInterval(spawnItem, 1200);
}

// akhir game
function endGame() {
  clearInterval(gameInterval);
  clearInterval(spawnInterval);
  popup.classList.remove("hidden");
}

// restart
function restartGame() {
  document.querySelectorAll(".falling").forEach(el => el.remove());
  startGame();
}

startGame();